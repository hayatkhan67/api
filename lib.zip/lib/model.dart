class Hard {
  String? name;
  int? age;
  List<dynamic>? detailList;
  DetailMap? detailMap;
  List<DetailListOfMap>? detailListOfMap;

  Hard(
      {this.name,
      this.age,
      this.detailList,
      this.detailMap,
      this.detailListOfMap});

  Hard.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    age = json['age'];
    detailList = json['detailList'].cast<dynamic>();
    detailMap = json['detailMap'] != null
        ? new DetailMap.fromJson(json['detailMap'])
        : null;
    if (json['detailListOfMap'] != null) {
      detailListOfMap = <DetailListOfMap>[];
      json['detailListOfMap'].forEach((v) {
        detailListOfMap!.add(new DetailListOfMap.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    data['age'] = this.age;
    data['detailList'] = this.detailList;
    if (this.detailMap != null) {
      data['detailMap'] = this.detailMap!.toJson();
    }
    if (this.detailListOfMap != null) {
      data['detailListOfMap'] =
          this.detailListOfMap!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class DetailMap {
  String? learning;
  String? alkhidmat;
  int? rank;

  DetailMap({this.learning, this.alkhidmat, this.rank});

  DetailMap.fromJson(Map<String, dynamic> json) {
    learning = json['Learning'];
    alkhidmat = json['Alkhidmat'];
    rank = json['rank'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['Learning'] = this.learning;
    data['Alkhidmat'] = this.alkhidmat;
    data['rank'] = this.rank;
    return data;
  }
}

class DetailListOfMap {
  int? id;
  String? student;

  DetailListOfMap({this.id, this.student});

  DetailListOfMap.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    student = json['Student'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['Student'] = this.student;
    return data;
  }
}
